from openai import OpenAI

client = OpenAI(api_key='EMPTY', base_url='http://127.0.0.1:8060/v1', timeout=300, max_retries=0)
response = client.chat.completions.create(
    model='qwen',
    messages=[{'role': 'user', 'content': 'Give me a short introduction to large language models.'}],
    max_tokens=20,
    temperature=0.7,
    top_p=0.8,
    presence_penalty=1.5,
    extra_body={'top_k': 20, 'chat_template_kwargs': {'enable_thinking': False}},
    stream=True,
)
for chunk in response:
    if chunk.choices and chunk.choices[0].delta.content:
        print(chunk.choices[0].delta.content, end='', flush=True)
print()
