import socket
import torch
assert torch.cuda.device_count() == 4
for device in range(4):
    free, total = torch.cuda.mem_get_info(device)
    print(device, 'free GiB:', round(free / 2**30, 2))
    assert free / 2**30 >= 30, '先停止自己的旧服务或换空闲卡'
with socket.socket() as endpoint:
    endpoint.bind(('127.0.0.1', 8060))
print('FOUR_GPUS_AND_PORT_READY')
