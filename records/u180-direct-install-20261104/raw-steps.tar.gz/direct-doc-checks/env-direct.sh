export REPRO_ROOT=/workspace/repro
export REPO_DIR="$REPRO_ROOT/src/vllm-plugin-FL"
export PATH=/usr/local/bin:/usr/local/sbin:/usr/sbin:/usr/bin:/sbin:/bin
unset VIRTUAL_ENV PYTHONHOME PYTHONPATH VLLM_VENDOR
export PYTHONNOUSERSITE=1
export GIT_CONFIG_GLOBAL="$REPRO_ROOT/gitconfig"
export FLAGCX_PATH=/mnt/share/user_homes/iluv/FlagCX
export LD_LIBRARY_PATH="$FLAGCX_PATH/build/lib:/usr/local/corex/lib64${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
if [ -f "$REPRO_ROOT/driver-extracted/corex/lib64/libixthunk.so" ]; then
  export LD_LIBRARY_PATH="$REPRO_ROOT/driver-extracted/corex/lib64:$LD_LIBRARY_PATH"
fi
export CUDA_VISIBLE_DEVICES="${REPRO_DEVICES:-0,1,2,3}"
export COREX_VISIBLE_DEVICES="$CUDA_VISIBLE_DEVICES"
export VLLM_PLUGINS=fl
export USE_FLAGGEMS=1
export GEMS_VENDOR=iluvatar
export VLLM_ENGINE_ITERATION_TIMEOUT_S=36000
export VLLM_RPC_TIMEOUT=36000000
export VLLM_EXECUTE_MODEL_TIMEOUT_SECONDS=3600
export XDG_CACHE_HOME="$REPRO_ROOT/cache"
export TRITON_CACHE_DIR="$REPRO_ROOT/cache/triton"
export HF_HOME="$REPRO_ROOT/cache/huggingface"
export VLLM_CACHE_ROOT="$REPRO_ROOT/cache/vllm"
