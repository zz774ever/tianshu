import ctypes
import json
import os
import sys
from importlib import metadata
from pathlib import Path
import torch
import triton
import vllm
import vllm_fl
from vllm.platforms import current_platform
from vllm_fl.distributed.device_communicators import flagcx

assert sys.prefix == sys.base_prefix, sys.executable
assert vllm.__version__.split('+')[0] == '0.32.0', vllm.__version__
assert Path(os.environ['REPRO_ROOT'], 'src/vllm').resolve() in Path(vllm.__file__).resolve().parents
assert Path(os.environ['REPO_DIR']).resolve() in Path(vllm_fl.__file__).resolve().parents
versions = {name: metadata.version(name) for name in ('torch', 'flagtree', 'flag-gems', 'numpy')}
before = json.loads(Path(os.environ['REPRO_ROOT'], 'logs/core-before-upgrade.json').read_text())
assert versions == before, (before, versions)
assert hasattr(triton._C.libtriton, 'iluvatar')
assert current_platform.vendor_name == 'iluvatar'
assert torch.cuda.is_available()
assert (torch.ones(4, device='cuda') + 2).cpu().tolist() == [3, 3, 3, 3]
source = json.loads(metadata.distribution('flaggems-vllm').read_text('direct_url.json') or '{}')
assert source.get('vcs_info', {}).get('commit_id') == 'b5c2c2249319277ccda4d41aa0f65164bd9b2a19'
ctypes.CDLL(os.environ['FLAGCX_PATH'] + '/build/lib/libflagcx.so')
assert flagcx._flagcx_available
print('Python:', sys.executable)
print('vLLM:', vllm.__version__, vllm.__file__)
print('plugin:', vllm_fl.__file__)
print('core versions:', versions)
print('DIRECT_ENV_PASS')
