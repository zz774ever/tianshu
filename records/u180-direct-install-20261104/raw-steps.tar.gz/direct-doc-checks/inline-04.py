import json
import os
from importlib import metadata
from pathlib import Path
names = ('torch', 'flagtree', 'flag-gems', 'numpy')
versions = {name: metadata.version(name) for name in names}
Path(os.environ['REPRO_ROOT'], 'logs/core-before-upgrade.json').write_text(json.dumps(versions, indent=2))
print(versions)
