bash -c tail\ -n\ 14\ /workspace/repro/logs/\*system032-27b-direct-serve\*/output.log 
