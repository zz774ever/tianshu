python /workspace/repro/direct-doc-checks/inline-05.py 
