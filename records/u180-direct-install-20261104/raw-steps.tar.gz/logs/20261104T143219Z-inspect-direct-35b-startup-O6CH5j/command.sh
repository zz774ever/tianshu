bash -c tail\ -n\ 16\ /workspace/repro/logs/\*system032-35b-direct-serve\*/output.log\ 2\>/dev/null 
