bash -c tail\ -n\ 5\ /workspace/repro/logs/\*system032-27b-direct-serve\*/output.log 
