bash -c tail\ -n\ 4\ /workspace/repro/logs/\*system032-27b-direct-serve\*/output.log 
