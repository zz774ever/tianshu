git config --file /workspace/repro/gitconfig url.file:///workspace/repro/src/FlagGems-vllm.insteadOf https://github.com/flagos-ai/FlagGems-vllm.git 
