python /workspace/repro/direct-doc-checks/inline-06.py 
