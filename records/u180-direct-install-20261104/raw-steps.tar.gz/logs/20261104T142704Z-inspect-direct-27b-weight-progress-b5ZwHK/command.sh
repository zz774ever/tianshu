bash -c tail\ -n\ 12\ /workspace/repro/logs/\*system032-27b-direct-serve\*/output.log 
