cp /workspace/repro/direct-doc-checks/env-direct.sh /workspace/repro/env-direct.sh 
