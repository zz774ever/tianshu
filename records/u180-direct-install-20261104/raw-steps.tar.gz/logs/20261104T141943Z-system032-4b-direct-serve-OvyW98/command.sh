vllm serve /models/Qwen3-4B/ --served-model-name qwen --host 127.0.0.1 --enforce-eager --port 8060 --max-model-len 32768 
