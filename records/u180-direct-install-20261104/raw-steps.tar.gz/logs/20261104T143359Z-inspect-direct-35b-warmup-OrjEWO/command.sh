bash -c tail\ -n\ 14\ /workspace/repro/logs/\*system032-35b-direct-serve\*/output.log 
