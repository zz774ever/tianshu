env NO_PROXY=127.0.0.1\,localhost no_proxy=127.0.0.1\,localhost python /workspace/repro/direct-doc-checks/inline-03.py 
