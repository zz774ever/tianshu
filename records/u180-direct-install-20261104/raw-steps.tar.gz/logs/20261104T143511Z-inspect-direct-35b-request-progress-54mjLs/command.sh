bash -c tail\ -n\ 8\ /workspace/repro/logs/\*system032-35b-direct-serve\*/output.log 
