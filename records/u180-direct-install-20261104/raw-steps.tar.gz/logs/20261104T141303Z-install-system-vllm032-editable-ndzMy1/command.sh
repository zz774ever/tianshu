env -u PYTHONPATH -u VLLM_VENDOR VLLM_TARGET_DEVICE=empty VLLM_VERSION_OVERRIDE=0.32.0 /usr/local/bin/python -m pip install -v --no-build-isolation --no-deps -e /workspace/repro/src/vllm 
