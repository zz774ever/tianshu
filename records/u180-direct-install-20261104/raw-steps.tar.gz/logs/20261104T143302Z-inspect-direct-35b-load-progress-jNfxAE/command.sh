bash -c tail\ -n\ 12\ /workspace/repro/logs/\*system032-35b-direct-serve\*/output.log 
