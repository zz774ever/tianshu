env -u PYTHONPATH -u VLLM_VENDOR /usr/local/bin/python -m pip install --no-build-isolation --no-deps -e /workspace/repro/src/vllm-plugin-FL 
